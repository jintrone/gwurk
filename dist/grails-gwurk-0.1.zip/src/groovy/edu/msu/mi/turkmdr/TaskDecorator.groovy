package edu.msu.mi.turkmdr

/**
 * Created by josh on 2/19/14.
 */
interface TaskDecorator {



}
