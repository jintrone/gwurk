package edu.msu.mi.turkmdr

/**
 * Created by josh on 2/19/14.
 */
public interface BeatListener {

    def beat(def beater,long timestamp)

}