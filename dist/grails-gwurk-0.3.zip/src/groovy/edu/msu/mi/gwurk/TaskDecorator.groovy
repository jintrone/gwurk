package edu.msu.mi.gwurk

/**
 * Created by josh on 2/19/14.
 */
interface TaskDecorator {



}
