modules = {
    application {
        dependsOn 'jquery'
        resource url:'js/application.js'
    }


}