package edu.msu.mi.gwurk

class JavascriptController {

    def turk() {

    }
}
